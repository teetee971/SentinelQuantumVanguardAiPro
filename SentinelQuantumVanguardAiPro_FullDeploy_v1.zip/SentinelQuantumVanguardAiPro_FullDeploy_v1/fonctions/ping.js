exports.ping = (req, res) => res.status(200).send("OK");
